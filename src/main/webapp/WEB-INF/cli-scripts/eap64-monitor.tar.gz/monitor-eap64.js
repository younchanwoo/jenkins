importPackage(org.jboss.as.cli.scriptsupport)  
importPackage(java.util)
 
//날짜포맷 변경을 위한 함수
Date.prototype.format = function() {
   var yyyy = this.getFullYear().toString();
   var mm = (this.getMonth()+1).toString();// getMonth() is zero-based
   var dd  = this.getDate().toString();
   var hh = this.getHours().toString();
    var MM = this.getMinutes().toString();
    var ss = this.getSeconds().toString();
   return yyyy + "-" + (mm[1]?mm:"0"+mm[0]) + "-" + (dd[1]?dd:"0"+dd[0]) + " " + (hh[1]?hh:"0"+hh[0]) + ":" + (MM[1]?MM:"0"+MM[0]) + ":" + (ss[1]?ss:"0"+ss[0]); // padding
};
 
// CLI접속
cli = CLI.newInstance()  
var host = "localhost"
var port = 9999
//cli.connect() 
cli.connect (host, port, "admin", new java.lang.String("rplinux12#").toCharArray())
 

 
// Get Connector and Executor Information
web_result = cli.cmd("/subsystem=web:read-resource(recursive=true)").getResponse().get("result")
connector_result = web_result.get("connector")
var connectors=connector_result.keys().toArray()
//print("connectors=" + connectors)


// Get Demployment Information for Active Session
deployment_result = cli.cmd(":read-resource").getResponse().get("result").get("deployment")
var deployment_names = deployment_result.keys().toArray()

// get the threads pools info. 
threads_result = cli.cmd("/subsystem=threads:read-resource(recursive=true)").getResponse().get("result")
//print("threads_result:" + threads_result.getClass())

var thread_pool_type_arr = ["blocking-bounded-queue-thread-pool", "blocking-queueless-thread-pool", "bounded-queue-thread-pool", "queueless-thread-pool", "scheduled-thread-pool", "unbounded-queue-thread-pool"]



// print("thread_type_map:" + thread_type_map.toString())

 
// Datasource 리스트
result = cli.cmd("/subsystem=datasources:read-resource")
var ds_set = java.util.Set
var ds_arr = result.getResponse().get("result").get("data-source").keys().toArray()

 

var time_end = 60 * 60 * 1  // 1시간
var Thread = java.lang.Thread;
for (var time=1; time < time_end; time++){
    var now = new Date().format()
    java.lang.System.out.printf("%19s\n", now)
 
    // Connector
    print ("============================================================")
    print (" Connector Information")
    print ("============================================================")

    // Print Title
    java.lang.System.out.printf("%-15s%20s%17s\n", "  Connector","executor", "max-connections")
    print ("  ----------------------------------------------------------")

    for (var i=0; i < connectors.length; i++){
        var connector = connectors[i]
        //var executor = ConnectorExecutorMap.get(connector)
        var executor = connector_result.get(connectors[i]).get("executor").asString()
        var max_connections = connector_result.get(connectors[i]).get("max-connections").asString()

        java.lang.System.out.printf("%-15s%20s%17s\n", "  " + connector, executor, max_connections)

    }

    print(" ")
    print(" ")

    // Connector
    print ("=============================================================================================")
    print (" Thread Pool Information")
    print ("=============================================================================================")
    
    threads_result = cli.cmd("/subsystem=threads:read-resource(recursive=true, include-runtime=true) ").getResponse().get("result")
    
    // Thread Pool Type
    for (var i=0; i < thread_pool_type_arr.length; i++){
        var thread_pool_type = thread_pool_type_arr[i]
        var thread_pool_type_result = threads_result.get(thread_pool_type)
        
         
        if (thread_pool_type_result.isDefined()) {
        	java.lang.System.out.printf("%-40s\n", "  " + thread_pool_type)
        	print ("  -----------------------------------------------------------------------------------------")
            thread_pool_arr = thread_pool_type_result.keys().toArray()
            
            // Print Thread-Pool Title
            java.lang.System.out.printf("%-25s%13s%14s%22s%22s\n", "    executor","max-threads", "active-count", "current-thread-count", "largest-thread-count")
            print ("    ---------------------------------------------------------------------------------------")
            // Thread Pool
            for (var j=0; j < thread_pool_arr.length; j++) {
                thread_pool_name = thread_pool_arr[j]
                thread_pool_name_result = thread_pool_type_result.get(thread_pool_name)
                
                max_threads = thread_pool_name_result.get("max-threads")
                active_count = thread_pool_name_result.get("active-count")
                current_thread_count = thread_pool_name_result.get("current-thread-count")
                largest_thread_count = thread_pool_name_result.get("largest-thread-count")
                java.lang.System.out.printf("%-25s%13s%14s%22s%22s\n", "      " + thread_pool_name,max_threads, active_count, current_thread_count, largest_thread_count)
            } 
        } else {
        	//java.lang.System.out.printf("%40s%10s\n", thread_pool_type, "Undefined")
        }

    }
    
    print(" ")
    print(" ")

    print ("============================================================")
    print (" Datasources Information")
    print ("============================================================")
    // Print Title
    java.lang.System.out.printf("%-15s%14s%14s%13s%12s%14s\n", "  Datasource","min-pool-size", "max-pool-size", "ActiveCount", "InUseCount", "MaxUsedCount")
    print ("  ------------------------------------------------------------------------------")

    // Print Datasource
    for (cnt=0; cnt < ds_arr.length; cnt++  ) {
        var datasource_name = ds_arr[cnt]
        // Datasource지정
        DATA_SOURCE="/subsystem=datasources/data-source=" + datasource_name
        
        // min / max 사이즈
        result = cli.cmd(DATA_SOURCE + ":read-resource(include-runtime=true)").getResponse().get("result")
        max_pool_size = result.get("max-pool-size").asString()
        min_pool_size = result.get("min-pool-size").asString()
        
        // pool 통계
        result = cli.cmd(DATA_SOURCE + "/statistics=pool:read-resource(include-runtime=true)").getResponse().get("result")
        ActiveCount = result.get("ActiveCount").asString()
        InUseCount = result.get("InUseCount").asString()
        MaxUsedCount = result.get("MaxUsedCount").asString()
        
        // 출력
        java.lang.System.out.printf("%-15s%14s%14s%13s%12s%14s\n", "  " + datasource_name, min_pool_size, max_pool_size, ActiveCount, InUseCount, MaxUsedCount)
    }
    
    //eempty line
    print(" ");
    print(" ");

    print ("============================================================")
    print (" Deployments Information")
    print ("============================================================")
 // Print Title
    java.lang.System.out.printf("%-15s%9s%17s\n", "  Deployment", "enabled", "active-sessions")
    print ("  ----------------------------------------------------------")

    // Print Deployments
    if (deployment_result.isDefined()){
        deployment_arr = deployment_result.keys().toArray()
        for (cnt=0; cnt < deployment_arr.length; cnt++  ) {
            deployment_name = deployment_arr[cnt]
            result = cli.cmd( "/deployment=" + deployment_name + ":read-resource(recursive=true, include-runtime=true)").getResponse().get("result")
            ActiveSession = result.get("subsystem").get("web").get("active-sessions").asString()
            Enabled = result.get("enabled").asString()

            // Print Deployment data
            java.lang.System.out.printf("%-15s%9s%17s\n", "  " + deployment_name, Enabled, ActiveSession)

        }

    } else {
           print("No Deployment")
           print(" ")
    }
    
    print(" ")
    print(" ")
    print(" ")

    Thread.sleep(2000)
}
// CLI 종료
cli.disconnect()

